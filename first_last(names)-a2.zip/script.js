// Simple form submission (you can enhance this with actual form submission logic)
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Form submitted!');
});
